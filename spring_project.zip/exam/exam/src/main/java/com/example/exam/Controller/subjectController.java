package com.example.exam.Controller;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.exam.Models.subject;
import com.example.exam.Repository.subjectRepository;

@RestController
public class subjectController {
	@Autowired
	subjectRepository subjects;
	@PostMapping("subject/add")
	public String addsubject(subject subject)
	{
		try
		{
			subjects.save(subject);
			return "record save";
//			return "redirect:/subject/display";
		}
		catch(Exception e)
		{
			return e.getMessage();
		}
	}
	@PostMapping("subject/delete")
	public String deletesubject(@RequestParam Integer id)
	{
		try
		{
			subjects.deleteById(id);
			return "subject Deleted";
		}
		catch(Exception ex)
		{
			return ex.getMessage();
		}
	}
	
	@PostMapping("subject/update")
	public String updatesubject(@RequestParam Integer id,@RequestParam String name,@RequestParam int marks)
	{
		try
		{
			subject subject=new subject();
			
			subject.setId(id);
			subject.setName(name);
			subject.setMarks(marks);
			subjects.save(subject);
			
			return "subject Updated Sucessfully";
		}
		catch(Exception ex)
		{
			return ex.getMessage();
		}
	}
	
	@PostMapping("subject/find")
	public String existssubject(@RequestParam Integer id)
	{
		try
		{
			if(subjects.existsById(id))
			{
				return "subject Exist";
			}
			else
			{
				return "subject not Exist";
			}
		}
		catch(Exception ex)
		{
			return ex.getMessage();
		}
	}
	@GetMapping("/subject/display")
    public String listsubject(Model model) 
	{ 
        List<subject> subjectList = (List<subject>) subjects.findAll();
        model.addAttribute("subjects", subjectList);  
        return "display";  
    }
}