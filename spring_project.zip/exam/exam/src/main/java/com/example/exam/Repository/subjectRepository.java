package com.example.exam.Repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.example.exam.Models.subject;

@Repository
public interface subjectRepository extends CrudRepository<subject, Integer> {

}

