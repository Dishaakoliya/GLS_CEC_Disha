package com.example.demu;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemuApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemuApplication.class, args);
	}

}
