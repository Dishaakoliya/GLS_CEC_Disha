package com.example.demu.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demu.Models.Student;
import com.example.demu.Repository.StudentRepository;
@RestController
public class StudentController {
	@Autowired
	StudentRepository students;
	
	@PostMapping("student/add")
	public String addStudent(Student student)
	{
		try
		{
			students.save(student);
			return "record save";
		}
		catch(Exception e)
		{
			return e.getMessage();
		}
	}
}
