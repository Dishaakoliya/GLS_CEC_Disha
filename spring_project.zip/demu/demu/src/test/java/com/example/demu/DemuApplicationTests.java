package com.example.demu;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemuApplicationTests {

	@Test
	void contextLoads() {
	}

}
